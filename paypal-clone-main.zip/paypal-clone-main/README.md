PayPal clone built using [Next.js](https://nextjs.org/).

Deployed on [Vercel](https://vercel.com/home?utm_source=next-site&utm_medium=banner&utm_campaign=next-website)

UI was created using [TailwindCSS](https://tailwindcss.com/)
