import Register from "../components/auth/register";

export default function Signup() {
  return (
    <div>
      <Register />
    </div>
  );
}
