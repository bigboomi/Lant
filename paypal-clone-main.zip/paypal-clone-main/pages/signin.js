import Login from "../components/auth/login";

export default function Signin() {
  return (
    <div>
      <Login />
    </div>
  );
}
