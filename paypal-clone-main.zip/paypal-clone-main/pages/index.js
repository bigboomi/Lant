import Components from "../components/app";

export default function Home() {
  return (
    <div>
      <Components />
    </div>
  );
}
