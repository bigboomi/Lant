import FooterBottom from "./footerBottom";
import FooterTop from "./footerTop";

export default function AppFooter() {
  return (
    <>
      <FooterTop />
      <FooterBottom />
    </>
  );
}
